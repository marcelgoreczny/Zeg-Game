// Pobranie canvas z HTML
const canvas = document.getElementById("gameCanvas");

// Kontekst rysowania 2D
const ctx = canvas.getContext("2d");

// Elementy interfejsu
const hpText = document.getElementById("hp");
const levelText = document.getElementById("level");
const itemsText = document.getElementById("items");
const message = document.getElementById("message");

// Przyciski
const startButton = document.getElementById("startButton");
const restartButton = document.getElementById("restartButton");

// Rozmiar pojedynczego pola
const tileSize = 64;

// Liczba kolumn
const cols = 10;

// Liczba wierszy
const rows = 10;

// Mapa poziomu
// 0 = przejście
// 1 = ściana
const maze = [
    [1,1,1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,1],
    [1,0,1,1,1,0,1,1,0,1],
    [1,0,0,0,1,0,0,1,0,1],
    [1,1,1,0,1,1,0,1,0,1],
    [1,0,0,0,0,0,0,1,0,1],
    [1,0,1,1,1,1,0,1,0,1],
    [1,0,0,0,0,1,0,0,0,1],
    [1,0,1,1,0,0,0,1,0,1],
    [1,1,1,1,1,1,1,1,1,1]
];

// Dane gracza
const player = {
    x: 1,
    y: 1,
    hp: 100,
    items: 0
};

function drawMaze() {

    for (let row = 0; row < rows; row++) {

        for (let col = 0; col < cols; col++) {

            // Sprawdzenie czy pole jest ścianą
            if (maze[row][col] === 1) {
                ctx.fillStyle = "black";
            } else {
                ctx.fillStyle = "white";
            }

            // Rysowanie pola
            ctx.fillRect(
                col * tileSize,
                row * tileSize,
                tileSize,
                tileSize
            );
        }
    }
}

function drawPlayer() {

    ctx.fillStyle = "blue";

    ctx.fillRect(
        player.x * tileSize,
        player.y * tileSize,
        tileSize,
        tileSize
    );
}

window.addEventListener("keydown", function(event) {

    let newX = player.x;
    let newY = player.y;

    // Ruch w lewo
    if (event.key === "ArrowLeft" || event.key === "a") {
        newX--;
    }

    // Ruch w prawo
    if (event.key === "ArrowRight" || event.key === "d") {
        newX++;
    }

    // Ruch w górę
    if (event.key === "ArrowUp" || event.key === "w") {
        newY--;
    }

    // Ruch w dół
    if (event.key === "ArrowDown" || event.key === "s") {
        newY++;
    }

    // Sprawdzenie kolizji ze ścianą
    if (maze[newY][newX] === 0) {
        player.x = newX;
        player.y = newY;
    }

    // Odświeżenie gry
    drawGame();
});

// Lista przedmiotów
const items = [
    {
        x: 3,
        y: 1,
        type: "hp"
    },
    {
        x: 7,
        y: 7,
        type: "key"
    }
];

function drawItems() {

    ctx.fillStyle = "green";

    items.forEach(function(item) {

        ctx.fillRect(
            item.x * tileSize,
            item.y * tileSize,
            tileSize,
            tileSize
        );
    });
}

function collectItems() {

    items.forEach(function(item, index) {

        if (player.x === item.x && player.y === item.y) {

            // Leczenie gracza
            if (item.type === "hp") {
                player.hp += 20;
            }

            // Dodanie przedmiotu
            player.items++;

            // Usunięcie przedmiotu z mapy
            items.splice(index, 1);

            // Aktualizacja interfejsu
            updateUI();
        }
    });
}

// Lista przeciwników
const enemies = [
    {
        x: 5,
        y: 5
    }
];

function drawEnemies() {

    ctx.fillStyle = "red";

    enemies.forEach(function(enemy) {

        ctx.fillRect(
            enemy.x * tileSize,
            enemy.y * tileSize,
            tileSize,
            tileSize
        );
    });
}

function checkEnemyCollision() {

    enemies.forEach(function(enemy) {

        if (player.x === enemy.x && player.y === enemy.y) {

            // Odbieranie życia
            player.hp -= 20;

            updateUI();

            // Sprawdzenie końca gry
            if (player.hp <= 0) {
                message.innerText = "Koniec gry";
            }
        }
    });
}

// zagadki logiczne

function showPuzzle() {

    const answer = prompt("Ile jest 2 + 2?");

    if (answer === "4") {
        message.innerText = "Poprawna odpowiedź";
    } else {
        message.innerText = "Błędna odpowiedź";
    }
}

let currentLevel = 1;

//Po ukończeniu poziomu: zwiększa się numer poziomu, aktualizowany jest interfejs, pojawia się komunikat.

function nextLevel() {

    currentLevel++;

    levelText.innerText = currentLevel;

    message.innerText = "Przejście do kolejnego poziomu";
}

//Funkcja odświeża: HP, poziom, liczbę przedmiotów.

function updateUI() {

    hpText.innerText = player.hp;

    itemsText.innerText = player.items;

    levelText.innerText = currentLevel;
}

// GŁÓWNA FUNKCJA GRY

function drawGame() {

    // Czyszczenie ekranu
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Rysowanie elementów
    drawMaze();
    drawItems();
    drawEnemies();
    drawPlayer();

    // Sprawdzenia mechanik
    collectItems();
    checkEnemyCollision();
}

// rozpoczecie gry 

startButton.addEventListener("click", function() {

    // Ukrycie ekranu startowego
    document.getElementById("startScreen").style.display = "none";

    // Uruchomienie gry
    drawGame();
});

// restart gry 

restartButton.addEventListener("click", function() {

    // Reset pozycji gracza
    player.x = 1;
    player.y = 1;

    // Reset życia
    player.hp = 100;

    // Reset przedmiotów
    player.items = 0;

    // Reset komunikatu
    message.innerText = "";

    // Aktualizacja interfejsu
    updateUI();

    // Ponowne uruchomienie gry
    drawGame();
});

